# Avance — 17-09-2026 — Presentacion de Avances

Se creó una presentación HTML de 14 diapositivas que resume los resultados
experimentales cerrados al 14-09-2026. Archivo en el repositorio:
`presentaciones/Avances-Tesis-MDS-17-09-2026.html`.

Incluye objetivos profesor/estudiante, evaluación por participantes, grids de
BiLSTM, LSTM, TCN y Transformer, controles temporales, ablación, PCA y clase media.
Mantiene explícito que ninguna red del último grid supera a Ridge y que 0,3843
sin fixation_count es un máximo exploratorio pendiente de confirmación.
Las propuestas de trabajo futuro quedan como decisiones pendientes.

La presentación funciona sin conexión, con navegación por teclado, selector,
lectura continua e impresión de las 14 diapositivas. Fuentes relativas al repositorio.
22 comprobaciones aprobadas; axe-core sin violaciones detectadas a 1440, 720 y
320 píxeles. Limitaciones de auditoría documentadas: sin lector de pantalla real
ni prueba manual del zoom del navegador. No se hicieron nuevos entrenamientos.

Commit de presentación y verificación: `cfc23aa`.
Documentación: `documentacion/Presentacion_Avances_17-09-2026.md`.
Respaldo de esta sección: `documentacion/Tesis_Vault_Presentacion_17-09-2026.zip`.

Relacionado: [[Tesis_MDS]] · [[Avance - 14-09-2026 (Grid Search BiLSTM LSTM y TCN)]]
