# Avance — 10-09-2026: Publicacion de Iteraciones

Se completó la publicación pendiente de [[Avance - 08-09-2026 (Iteraciones de Mejora)]].
GitHub confirmó `git push origin main`, commit `79d0b48`, el 10-09-2026.
La entrega incluye 137 archivos: código, informe, resultados y 90 archivos de modelos.
Se verificaron 133 hashes de código y resultados contra los objetos preparados en Git.

Los entrenamientos y sus auditorías corresponden al 08-09-2026: 795 ajustes internos,
243.432 predicciones externas verificadas y 33 pruebas aprobadas. No se repitió el
entrenamiento ni se evaluó nuevamente test durante esta publicación.

El mejor promedio observado sigue siendo BA macro 0,3546 frente a logística 0,3536;
la diferencia de +0,11 puntos porcentuales tiene un intervalo que incluye cero.
No hay evidencia de superioridad estable.

Las notas de tesis quedan respaldadas en `documentacion/Tesis_Vault_10-09-2026.zip`,
con inventario y hashes por archivo. Se conservan los respaldos anteriores.

Fuente: estado de Git, comprobación de hashes y respuesta de GitHub del 10-09-2026.

## Notas relacionadas

- [[Tesis_MDS]]
- [[Avance - 08-09-2026 (Iteraciones de Mejora)]]
