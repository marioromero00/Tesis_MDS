# Avance — 20-09-2026 — Presentacion Acotada del Tema

Se preparó una presentación de seis diapositivas, en un único HTML autocontenido:
`Tesis_MDS/presentaciones/Presentacion-Tema-Tesis-Autocontenida-20-09-2026.html`.

Incluye tema y profesor guía, antecedentes, objetivo general, los siete objetivos
específicos resumidos, metodología y datos disponibles. La portada identifica al
Dr. Juan D. Velásquez como profesor guía. La codirección del proyecto Fondecyt
no se presenta como coguía formal de tesis sin confirmación.

Usa el alcance operacional de atención y activación emocional del índice vigente.
Conserva la separación Modelo Profesor / Modelo Estudiante y el análisis descriptivo
de fatiga/habituación. Los datos distinguen 48 personas auditadas de 41 del conjunto
principal: 25 entrenamiento, 8 validación y 8 prueba; seis excluidas y un caso de sensibilidad.

31 comprobaciones aprobadas; cero dependencias externas y cero solicitudes HTTP en
una copia aislada con el navegador offline. Navegación por teclado, lectura continua,
vista móvil, contraste y seis páginas de impresión verificados. axe-core sin violaciones
detectadas en tres anchos; sin prueba con lector de pantalla real.

Commit de presentación: `51e390e`. Informe y verificación en
`documentacion/Presentacion_Tema_20-09-2026.md` y su JSON asociado.
Respaldo de esta sección: `documentacion/Tesis_Vault_Presentacion_Tema_20-09-2026.zip`.

La presentación de avances del 17-09 se conserva: esta versión sirve para describir
el tema y el diseño del trabajo. No modifica los objetivos originales ni los resultados.

Fuentes: [[Estructura Tesis]], [[Problema e hipótesis]], [[PREPROCESAMIENTO_MULTIMODAL]],
[[DOCUMENTACION_DATOS_MDS]], [[ETIQUETAS_Y_BASELINES]] y [[Tesis_MDS]].
