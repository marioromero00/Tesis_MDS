

  
Eye tracking y pupilometria -> hacer correlato y justificar el porque elegir esto, en verdad porque elegí cada señal como profesor y estudiante Mirar paper sobre atención, 

  

Sobre atención  ->Atención depende de esfuerzo cognitivo .Lo que quiero es focalizar en una parte de la atención no completa

  

Sobre tevolucion de la atención en el tiempo. Algoritmo de convolución -> TCN.

  

La ventana es 4 en el rol de tiempo