# Avance - 10-08-2026 (Hipótesis de Investigación)

## Trabajo realizado

- Se actualizó [[Problema e hipótesis]] al diseño de la Toma de Muestra 2: EEG, GSR, Eye
  Tracking y Pupilometría, sin expresión facial.
- El investigador confirmó una sola hipótesis central: los modelos temporales multimodales
  obtienen un mejor desempeño fuera de muestra que los modelos estáticos comparables en la
  detección de emociones y atención durante la navegación web.
- Emociones y atención quedaron como dos resultados de la misma hipótesis, no como
  hipótesis independientes.
- Fatiga y habituación quedaron como posible análisis complementario, no como una segunda
  hipótesis.
- Se incorporaron la hipótesis nula asociada, criterios de interpretación y amenazas a la
  validez.

## Decisiones que permanecen abiertas

- Confirmar con el profesor guía si el alcance de “emoción” puede restringirse a
  arousal/activación.
- Definir la métrica primaria, la prueba estadística y el número de repeticiones para
  contrastar H1.
- Decidir si se mantendrá el análisis complementario de tendencias intra-sesión.
- Resolver las decisiones del *Modelo Profesor* registradas en
  [[Modelo Profesor - Decisiones]].

## Notas relacionadas

- [[Tesis_MDS]]
- [[Problema e hipótesis]]
- [[Resumen Diseño Etiquetas y Modelos]]
