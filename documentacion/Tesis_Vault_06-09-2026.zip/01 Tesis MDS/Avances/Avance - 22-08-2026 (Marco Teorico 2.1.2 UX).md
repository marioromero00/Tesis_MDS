# Avance - 22-08-2026 (Marco Teórico 2.1.2 Experiencia Usuario)

Redacción de la subsección 2.1.2 de [[Estructura Tesis]], que desde el 17-08-2026 estaba como
esqueleto de bullets con referencias transcritas de bibliografías ajenas.

## Qué se hizo

El esqueleto pasó a prosa: cinco párrafos y una lista de principios. La subsección cierra con el
párrafo puente que justifica la tesis dentro del marco de UX, que es el argumento de por qué se
mide de forma continua en vez de por sesión.

**Verificación de referencias.** Antes de redactar se extrajeron los PDF de las memorias de López
y Saffie (`~/Tesis_MDS/Tesis/Tesis años previos/`) y se contrastó cada referencia contra su
bibliografía y contra el uso que cada memoria le da. Quedó confirmado que la entrada bibliográfica
existe y qué dice de ella la memoria de origen. **Las fuentes primarias siguen sin leerse**: la
advertencia del 17-08 se mantiene, ahora acotada. Las entradas completas quedaron transcritas en
un blockquote de la propia subsección para armar el `.bib`.

Dos correcciones respecto del esqueleto:

- **Los principios de diseño web son cinco, no cuatro.** El esqueleto omitía accesibilidad;
  Husseniy et al. (2021), según la transcripción de López, la incluye.
- **Statista quedó fechado en el texto (2024)** en vez de presentarse como dato actual. Es la
  versión que usa Saffie: 8 h 31 min en Chile contra 6 h 40 min de promedio mundial, quinto lugar.
  Actualizar a 2026 sigue pendiente, pero mientras tanto la cifra es citable sin mentir sobre su año.

## Decisiones tomadas

- **La subsección no menciona la ventana de 2 s.** Habla de "ventanas" y deja el soporte temporal
  al Cap. 4. Así la decisión abierta del GSR puede cerrarse sin obligar a reescribir el marco teórico.
- **"Activación emocional", no "emoción"**, en línea con el Cap. 1. La redefinición como *arousal*
  sigue sin confirmar por el profesor guía, y el término que se usa aquí no depende de esa confirmación.
- **La definición ISO se cita vía González & Marcos (2013)**, como en Saffie, y queda marcado como
  pendiente citar ISO 9241-210 directamente. Es una cita de segunda mano declarada, no encubierta.

## Pendientes que esto deja

- [ ] Leer las 7 fuentes primarias de 2.1.2 antes de la defensa. La lista con datos completos está
  en el blockquote de la subsección.
- [ ] Reemplazar el dato de Statista por la edición 2026, o dejarlo fechado como está.
- [ ] Citar ISO 9241-210 directamente.
- [ ] Redactar 2.2 Emociones Humanas, la siguiente sección del Cap. 2 en blanco.

## Notas relacionadas

- [[Estructura Tesis]] — Cap. 2, sección 2.1
- [[Avance - 17-08-2026 (Capitulo 1 y Marco Teorico 2.1)]] — de donde venía el esqueleto
- [[Referencia Tesis Previas]]
- [[Tesis_MDS]]
