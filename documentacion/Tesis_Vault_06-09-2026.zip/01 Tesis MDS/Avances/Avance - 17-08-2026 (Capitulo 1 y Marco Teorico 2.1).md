# Avance - 17-08-2026 (Capítulo 1 y Marco Teórico 2.1)

## Trabajo realizado

Se completaron en [[Estructura Tesis]] cuatro secciones que estaban *(pendiente)*:

- **Objetivos.** Objetivo general definido por el investigador; 7 objetivos específicos. Forma calibrada leyendo los objetivos textuales de las 6 memorias previas (rango 4–7, infinitivo, una oración, orden build-up).
- **Alcances y limitaciones.** Separados por criterio explícito: alcance = recorte decidido, limitación = restricción sufrida. Los alcances en lista (forma de Villanueva); las limitaciones en tres grupos (pseudoetiquetas / señales y sincronización / diseño e inferencia), consolidando material que ya existía repartido en [[Problema e hipótesis]], [[Etiqueta Atencion]], [[Etiqueta Emocion]] y [[Avance EDA y Sincronizacion - 15-08-2026]].
- **Contribuciones del trabajo.** 6, redactadas como entregables (forma de Villanueva) y no como objetivos en pasado (forma de Subiabre).
- **Marco teórico 2.1** (IHC y UX). Esqueleto con referencias extraídas de las bibliografías de López y Saffie.

## Decisiones tomadas

- **El análisis de fatiga y habituación entra al alcance.** Era decisión abierta en [[Avance - 10-08-2026 (Hipotesis de Investigacion)]]; al quedar como objetivo específico 6 pasa a ser exigible en la defensa.
- Las contribuciones 1, 2 y 6 se redactan como "evidencia sobre" y no como promesa de hallazgo, para que un resultado nulo no las desmienta.

## Pendientes que esto deja

- [ ] **Conservar el score continuo** además del discretizado en ambas etiquetas: el objetivo 6 lo exige y el pipeline aún no lo contempla.
- [ ] **Corregir las dos menciones a expresión facial** que quedaron del diseño anterior en [[Estructura Tesis]]: Cap. 1 "Descripción Proyecto" y Cap. 3 "Aporte de esta tesis". Contradicen las contribuciones recién escritas.
- [ ] **Verificar las referencias de 2.1** antes de citarlas: fueron transcritas de bibliografías ajenas, no leídas.
- [ ] Actualizar el dato de Statista a 2026.
- [ ] Revisar si el protocolo de partición disjunta coincide con el supuesto de *view independence* de co-training; si es así, citarlo antes de presentarlo como aporte propio.
- [ ] **Confirmar el alcance de *arousal* con el profesor guía.** Sigue abierto y ahora cuelgan de él tres secciones del Cap. 1: objetivo específico 3, alcance 2 y contribución 1.

## Notas relacionadas

- [[Estructura Tesis]]
- [[Problema e hipótesis]]
- [[Referencia Tesis Previas]]
- [[Tesis_MDS]]
