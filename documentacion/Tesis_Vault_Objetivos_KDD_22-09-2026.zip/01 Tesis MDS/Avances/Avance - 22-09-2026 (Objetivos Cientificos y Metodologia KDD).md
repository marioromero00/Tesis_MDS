# Avance — 22-09-2026 — Objetivos Cientificos y Metodologia KDD

Se revisaron, a solicitud de Mario, los objetivos y la metodología de la presentación del tema de tesis. Esta revisión reemplaza la redacción de objetivos del 17-08-2026 y las láminas correspondientes de la entrega del 20-09-2026. Los archivos se actualizaron en sus rutas originales:

- `Tesis_MDS/presentaciones/Presentacion-Tema-Tesis-Autocontenida-20-09-2026.html`.
- `Tesis_MDS/presentaciones/Presentacion-Tema-Tesis-Autocontenida-20-09-2026.pptx`.

El objetivo general quedó centrado en evaluar el aporte de la temporalidad y la fusión a la predicción de pseudoetiquetas, comparando modelos en participantes no utilizados para su ajuste. Los siete específicos se reformularon con resultados evaluables: caracterización, comparación, cuantificación e incertidumbre. Se conserva el análisis intra-sesión descriptivo de fatiga/habituación. La redacción íntegra vive en [[Estructura Tesis]] y coincide con ambas presentaciones; el objetivo general también se actualizó en [[Tesis_MDS]].

Se adoptó **KDD**, ya previsto en el borrador, con cinco bloques para la presentación: selección, preprocesamiento, transformación, minería de datos e interpretación/evaluación. Se documentó la adaptación en el capítulo metodológico y se corrigió una remisión antigua al enfoque facial descartado. Se mantiene la separación de señales entre Modelo Profesor y Modelo Estudiante. No se modificaron los resultados ni las pseudoetiquetas; las búsquedas anteriores conservan su alcance exploratorio.

Fuente externa consultada el 22-09-2026: Fayyad, Piatetsky-Shapiro y Smyth (1996), *From Data Mining to Knowledge Discovery in Databases*, AI Magazine 17(3), 37–54. [Texto primario](https://fayyad.com/from-data-mining-to-knowledge-discovery-in-databases/), DOI 10.1609/aimag.v17i3.1230. Los cinco bloques sintetizan el proceso desarrollado en nueve pasos en el artículo.

Verificación: 31 comprobaciones del HTML aprobadas, seis páginas de impresión y revisión de accesibilidad automatizada sin violaciones detectadas en tres anchos. El PowerPoint conserva seis diapositivas editables; apertura y renderizado real sin texto desbordado, PDF de seis páginas y hashes verificados. Objetivos cotejados automáticamente contra el borrador. Se revisó la legibilidad de las láminas modificadas. No se probó la importación en Canva ni un lector de pantalla real.

Detalle e informes: `Tesis_MDS/documentacion/Revision_Objetivos_KDD_22-09-2026.md` y verificaciones del 22-09-2026. Respaldo de esta sección: `Tesis_MDS/documentacion/Tesis_Vault_Objetivos_KDD_22-09-2026.zip`.

Commit de las presentaciones, scripts e informes: `46b054d`.

Relacionados: [[Tesis_MDS]], [[Estructura Tesis]], [[Avance - 20-09-2026 (Presentacion Acotada del Tema)]].
