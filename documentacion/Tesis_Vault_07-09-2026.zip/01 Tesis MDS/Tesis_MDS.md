
# Tesis MDS

## Objetivo
Desarrollar y evaluar modelos temporales multimodales para la detección de atención y
activación emocional durante la navegación web, comparando su desempeño fuera de muestra con
modelos estáticos comparables y contrastando distintas estrategias de fusión multimodal.

Cuatro señales de la Toma de Muestra 2: **EEG, GSR, eye tracking y pupilometría**. Sin
expresión facial — esa señal está en la Toma de Muestra 1, no en este dataset.
Objetivo general y los 7 específicos, en [[Estructura Tesis]] > Objetivos.

## Estado actual
- 07-09-2026 — **Análisis y modelos reducidos publicados en GitHub**, rama `main`,
  commit `2575183`: 84 modelos nuevos, informes, figuras, predicciones, código y pruebas.
  Respaldo actualizado de notas fechado 07-09-2026.
  Detalle: [[Avance - 07-09-2026 (Publicacion de Analisis en GitHub)]].
- 07-09-2026 — **Contraste de estabilidad terminado: 5 folds por participante en train.**
  180 ajustes internos, 36 pipelines finales y panel de entradas congelado. La mejora
  inicial de pupila sola no se sostuvo; el compacto de atención selecciona 9 columnas
  estables, pero pierde desempeño en RF. Se mantienen los completos como referencia.
  18 pruebas y auditoría de 486.864 predicciones aprobadas; test sin nueva evaluación.
  Fuente vigente: [[Avance - 07-09-2026 (Estabilidad y Reduccion de Variables)]].
- 07-09-2026 — **Análisis exploratorio de importancia y reducción de variables.**
  Activación: pupila sola (6) y mirada + pupila (16) son candidatas frente a 25 entradas;
  las mejoras puntuales de clasificación en validación aún tienen incertidumbre amplia.
  Atención sigue cerca del nivel trivial; el top-5 incluye redundancia y ruido eléctrico.
  Se conservaron etiquetas/split y no se volvió a evaluar test.
  Informe y resultados: [[Avance - 07-09-2026 (Importancia de Variables)]].
- 06-09-2026 — **Trabajo de tesis publicado en GitHub**, repositorio público
  `marioromero00/Tesis_MDS`, rama `main`, commit de entrega `8757e98`.
  Incluye modelos, predicciones, métricas, código, presentación y un respaldo completo de
  esta sección en ZIP. Es un respaldo de tesis, no sincronización de la bóveda completa.
  Detalle: [[Avance - 06-09-2026 (Respaldo Completo en GitHub)]].
- 06-09-2026 — **Presentación HTML actualizada con los resultados de los baselines.**
  `presentaciones/avance-eda-sincronizacion-15-08-2026.html` tiene 16 diapositivas: protocolo,
  clasificación, regresión, sensibilidad, guardado y próximo contraste temporal.
  Se verificaron 45 cifras contra el CSV, navegación, imágenes y vista móvil.
  Fuente: [[Avance - 06-09-2026 (Presentacion Resultados Baselines)]].
- 05-09-2026 — **30 baselines entrenados y guardados como pipelines completos `.joblib`.**
  Mario confirmó que la validación metodológica ya estaba resuelta y pidió continuar.
  Se conservaron etiquetas y partición 25/8/8; la recarga de los 30 modelos reproduce exactamente
  predicciones y probabilidades. Diez pruebas aprobadas; métricas consistentes con el 22-08-2026.
  Repositorio local en esta máquina: `C:/Users/MarioRomero/desktop/mds/Tesis_MDS/`.
  Entrega en `resultados/modelado/ejecuciones/baselines_05-09-2026_02/` dentro del repositorio.
  Fuente vigente: [[Avance - 05-09-2026 (Baselines Entrenados y Guardados)]].
- 22-08-2026 — **Primera evaluación fuera de muestra terminada.** Se construyeron
  pseudoetiquetas sin circularidad, se congeló una división 25/8/8 por participante y se
  ejecutaron baselines. Los resultados estáticos quedaron alrededor del nivel trivial; la
  etiqueta de atención mostró baja robustez entre fusión igualitaria y PCA (ρ=0,454).
  Detalle en [[Avance - 22-08-2026 (Etiquetas Particion y Baselines)]].
- 22-08-2026 — **Pipeline multimodal secuencial ejecutado con los datos reales**: 25.992
  ventanas de 2 s, 22.201 válidas en las cuatro modalidades y 48 participantes auditados.
  Código, configuración, pruebas, hashes y resultados quedaron en el repo `Tesis_MDS`.
  Detalle en [[Avance - 22-08-2026 (Pipeline Multimodal Reproducible)]].
- 22-08-2026 — La selección del TXT principal se corrigió usando el archivo más largo por
  sesión. P48 queda recuperado; P25 se agrega a las exclusiones EEG. Resultado actualizado:
  **44/48 EEG utilizables**; P1, P14, P17 y P25 marcados por calidad.
- 22-08-2026 — **Preprocesamiento de GSR, pupilometría y eye tracking especificado y probado**
  en `~/tesis/Tesis_MDS/preprocesamiento/`: features en ventanas de 2 s
  con 50 % de solapamiento, el
  mismo soporte que las épocas del EEG. Verificado con datos sintéticos; **falta correrlo sobre
  el export real**, que está en Drive. Detalle en
  [[Avance - 22-08-2026 (Preprocesamiento GSR Pupila y Eye Tracking)]].
- 22-08-2026 — **Frecuencia del EEG resuelta: son 125 Hz**, verificada contra los datos crudos.
  Se eliminó la expresión facial de las siete secciones de [[Estructura Tesis]] donde seguía
  declarada como vigente. Detalle en
  [[Avance - 22-08-2026 (Frecuencia EEG y Limpieza de Expresion Facial)]].
  Deck de la presentación de avances armado en
  [[Avance Capitulo 1 y Verificaciones - 22-08-2026]] (10 diapositivas,
  `presentacion-22-08-26.html`).
- 24-08-2026 — **Vault consolidado.** La documentación del pipeline existía en tres copias
  desincronizadas; quedó una sola en `Analisis de Datos/`, con el contenido del 22-08-2026:
  12 notas planas y 16 figuras. Entran [[PREPROCESAMIENTO_MULTIMODAL]] y
  [[ETIQUETAS_Y_BASELINES]], que solo existían en la copia de la raíz. Detalle del retiro en
  [[Archivo]].
- 20-08-2026 — Primera consolidación de la documentación del pipeline en el vault, con
  [[Mapa del proyecto]] como MOC.
- 17-08-2026 — Capítulo 1 completo en [[Estructura Tesis]]: objetivos (general + 7 específicos),
  alcances y limitaciones, y contribuciones. Marco teórico 2.1 (IHC y UX) esquematizado con
  referencias por verificar. Detalle en [[Avance - 17-08-2026 (Capitulo 1 y Marco Teorico 2.1)]].
- 10-08-2026 — Capítulo de problema e hipótesis definido en [[Problema e hipótesis]].
  La hipótesis central quedó operacionalizada para emociones y atención, con hipótesis
  nula asociada, criterios de interpretación y amenazas a la validez.
- EDA de EEG terminado y corregido para sesiones con varios TXT.
- Preprocesamiento multimodal ejecutado y reproducible.

## Próximos pasos

> Actualización 05-09-2026: Mario confirmó la validación metodológica y autorizó continuar con
> los baselines, ya guardados. Los pendientes de aprobación listados abajo provienen del estado
> del 22-08-2026; no deben volver a tratarse como bloqueo de esta ejecución. La confirmación y el
> alcance conservado están en [[Avance - 05-09-2026 (Baselines Entrenados y Guardados)]].

**Bloqueado por el profesor guía**
- [ ] Confirmar que redefinir "emoción" como *arousal* es aceptable. De esto cuelgan el objetivo
  específico 3, el alcance 2 y la contribución 1 del Cap. 1.
- [ ] Aprobar el manifiesto de sincronización y los criterios finales de calidad.

**Metodología**
- [ ] Cerrar las 5 decisiones abiertas de [[Resumen Diseño Etiquetas y Modelos]] (fusión y
  umbrales de ambos scores, ventana de GSR por latencia de SCR, validación externa). La ventana
  del GSR ya se puede cerrar con evidencia: el preprocesamiento emite las features de SCR sobre
  2 s y sobre 6 s de contexto para poder comparar.
- [x] Conservar scores continuos y etiquetas ternarias para atención y activación.
- [x] Separar estrictamente las señales profesor y estudiante para evitar circularidad.

**Pipeline**
- [x] Analizar importancia, redundancias y subconjuntos en train/validación (07-09-2026).
- [x] Comprobar estabilidad en 5 folds y congelar el panel comparativo de entradas (07-09-2026).
- [x] Preprocesar GSR, eye tracking y pupilometría con los datos reales.
- [x] Validar nombres de columna y formato de fecha contra el TSV real.
- [x] Recortar ventanas comunes de 2 s por estímulo y límites UTC.
- [x] Integrar EEG, GSR, pupila y mirada en una tabla auditable de 59 columnas.
- [ ] Revisar con el profesor el offset de P29 y la aceptación de los criterios de calidad.
- [x] Implementar ambas pseudoetiquetas provisionales y entrenar baselines estáticos.
- [x] Congelar partición por participante: 25 train, 8 validación, 8 prueba; P29 sensibilidad.
- [x] Validación metodológica confirmada por Mario el 05-09-2026 para continuar con los baselines.
- [x] Entrenar, guardar y verificar recarga de los baselines completos (05-09-2026).
- [ ] Implementar TCN/LSTM solo manteniendo idéntica partición y etiquetas.

**Escritura**
- [ ] Verificar las referencias del Marco Teórico 2.1 antes de citarlas — fueron transcritas de
  bibliografías ajenas, no leídas. Actualizar el dato de Statista a 2026.
- [ ] Revisar si el protocolo de partición disjunta coincide con el supuesto de *view
  independence* de co-training; si es así, citarlo antes de presentarlo como aporte propio.
- [ ] Re-verificar la brecha 2 del Estado del Arte para la combinación sin expresión facial.
- [ ] Desarrollar el resto del Cap. 2; los Cap. 6 a 9 siguen en blanco.

## Decisiones importantes
- 22-08-2026 — **El EEG se registró a 125 Hz, no a 250 Hz.** La placa es OpenBCI Cyton + Daisy:
  el Cyton muestrea a 250 Hz con 8 canales y al agregar la Daisy para llegar a 16 el muestreo
  por canal cae a la mitad. La ventana de 2 s son **250 muestras**, no 500. Queda revertida la
  "corrección" a 250 Hz del 08-08-2026.
- 17-08-2026 — El análisis de fatiga y habituación **entra al alcance** como objetivo específico 6.
  Deja de ser opcional y obliga a conservar el score continuo además del discretizado.
- 10-08-2026 — La tesis tiene una sola hipótesis central. Fatiga y habituación quedan como
  posible análisis complementario, no como una segunda hipótesis. Detalle en
  [[Problema e hipótesis]].
- 08-08-2026 — Propuestas de resolución para las decisiones abiertas del modelo profesor en
  [[Modelo Profesor - Decisiones]]. Cuatro de siete se pueden cerrar sin el profesor guía; tres
  van a la reunión del 10-08. Sin confirmar aún.

## Qué no funcionó
Enfoques descartados y por qué — para no volver a razonarlos desde cero.

- **Clasificador facial como Modelo Profesor** (diseño previo, para atención y emoción).
  Descartado: la expresión facial existe en la Toma de Muestra 1, usada por otras tesis del
  grupo, pero **no en la Toma de Muestra 2**, que es este dataset. De ahí el rediseño
  profesor → estudiante con las 4 señales disponibles. Detalle en [[presentacion 10-08-26]].
- **Resumir las señales por promedios/medianas.** Descartado por pérdida de dinámica
  temporal — es justamente la limitación que la tesis busca atacar ([[Problema e hipótesis]]).
- **Fusión multimodal tardía como único enfoque.** No descartada, pero la literatura previa
  muestra mejoras marginales; por eso entra como una de tres alternativas a comparar, no
  como la elegida.

## Estructura

- `Avances/` — bitácora fechada.
- `Diseno Metodologico/` — etiquetas, modelos y decisiones metodológicas.
- `Marco Teorico/` — problema, conceptos y referencias previas.
- `Escritura/` — estructura y desarrollo del documento de tesis.
- `presentaciones/` — material para exposiciones: los punteos fechados, los HTML
  entregados y [[main_presentacion_mds]], la fuente LaTeX/Beamer del deck.
- `Analisis de Datos/` — documentación del pipeline en 12 notas planas, sincronizada al
  22-08-2026 desde el repositorio `~/tesis/Tesis_MDS`:
  [[Mapa del proyecto]] es su MOC.
- `attachments/Analisis de Datos/` — 16 figuras generadas por el pipeline.
  **El código y los datos viven fuera del vault**; las notas los citan por nombre de archivo
  (`eda_eeg.py`, `eeg_resumen_sesiones.csv`) en vez de enlazarlos.

## Notas relacionadas
- [[Avance - 07-09-2026 (Publicacion de Analisis en GitHub)]] — publicación de los dos
  análisis y respaldo de notas con inventario.
- [[Avance - 07-09-2026 (Estabilidad y Reduccion de Variables)]] — contraste interno,
  límites de la reducción y panel congelado para el siguiente experimento.
- [[Avance - 07-09-2026 (Importancia de Variables)]] — importancia por participante,
  reducción de entradas y candidatos para atención/activación.
- [[Avance - 06-09-2026 (Respaldo Completo en GitHub)]] — publicación de código, modelos,
  presentación y snapshot de las notas; alcance de la sincronización.
- [[Avance - 06-09-2026 (Presentacion Resultados Baselines)]] — HTML de 16 diapositivas,
  resultados y verificación de presentación.
- [[Avance - 05-09-2026 (Baselines Entrenados y Guardados)]] — modelos entrenados, ubicación,
  carga, métricas y confirmación de continuidad metodológica.
- [[Problema e hipótesis]] — problema, brechas, hipótesis central y criterios de
  interpretación.
- [[Avance - 10-08-2026 (Hipotesis de Investigacion)]] — registro del cierre de este
  capítulo.
- [[Avance - 17-08-2026 (Capitulo 1 y Marco Teorico 2.1)]] — objetivos, alcances,
  contribuciones y esqueleto de 2.1.
- [[Avance - 22-08-2026 (Marco Teorico 2.1.2 UX)]] — sección 2.1.2 de IHC y UX.
- [[Avance - 22-08-2026 (Frecuencia EEG y Limpieza de Expresion Facial)]] — verificación de la
  frecuencia contra los datos crudos y limpieza del diseño descartado en el borrador.
- [[Avance - 22-08-2026 (Preprocesamiento GSR Pupila y Eye Tracking)]] — módulo de features por
  ventana para las tres señales del Tobii.
- [[Avance - 22-08-2026 (Pipeline Multimodal Reproducible)]] — ejecución real, integración EEG,
  auditoría, hashes y correcciones P25/P48.
- [[Avance - 22-08-2026 (Etiquetas Particion y Baselines)]] — pseudoetiquetas, split congelado,
  auditoría P29 y primera evaluación fuera de muestra.
- [[Conocimiento Presentaciones Pasadas]] — consolidado de la presentación de junio 2026:
  EDA (48 participantes), pipeline EEG completo, los 273 features y la revisión de literatura.
