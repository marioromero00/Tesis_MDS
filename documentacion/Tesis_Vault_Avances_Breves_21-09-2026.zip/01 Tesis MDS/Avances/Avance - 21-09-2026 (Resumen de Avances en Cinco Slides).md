# Avance — 21-09-2026 — Resumen de Avances en Cinco Slides

Se creó una nueva presentación breve de los últimos avances, limitada a cinco
diapositivas: trabajo completado, resultados de grids, control temporal, ablación/PCA
y próximos pasos. Resume experimentos cerrados al 14-09; no presenta entrenamientos
nuevos como si se hubieran ejecutado después de esa fecha.

Entregables en el repositorio:
- `presentaciones/Avances-Resumen-Autocontenido-21-09-2026.html`.
- `presentaciones/Avances-Resumen-Autocontenido-21-09-2026.pptx`.

El HTML funciona sin conexión ni archivos adicionales y tiene navegación, lectura
continua e impresión. El PPTX conserva cinco láminas 16:9 con textos y formas editables
para importar en Canva. La presentación extensa del 17-09 se conserva.

HTML: 35 comprobaciones aprobadas; axe-core sin violaciones detectadas a 320, 720 y
1440 píxeles. PowerPoint: apertura y renderizado de cinco láminas, sin desbordamientos
de texto con tolerancia de dos puntos. PDF temporal de cinco páginas y hashes verificados.
No se probó la importación en Canva ni un lector de pantalla real.

Commit de los entregables y verificaciones: `54684e4`.
Informe: `documentacion/Avances_Breves_21-09-2026.md`.
Respaldo actualizado: `documentacion/Tesis_Vault_Avances_Breves_21-09-2026.zip`.

Fuentes: informes y CSV de grids recurrentes, Transformer y ablación/PCA.
Relacionados: [[Tesis_MDS]], [[Avance - 14-09-2026 (Grid Search BiLSTM LSTM y TCN)]],
[[Avance - 17-09-2026 (Presentacion de Avances)]].
