# Avance — 23-09-2026 — Presentacion Visual y KDD

Se reemplazó la presentación del tema de tesis para aclarar KDD y reducir la dependencia de explicaciones orales. Tiene siete láminas: tema y antecedentes, datos disponibles, objetivo general, objetivos específicos, recorrido KDD, construcción de etiquetas y comparación de modelos.

KDD se muestra como un proceso: cada etapa identifica una acción en esta tesis y el resultado que deja para la siguiente. La construcción de pseudoetiquetas y la evaluación ocupan láminas propias. Los diagramas muestran una ventana frente a una secuencia, la separación entre Modelo Profesor y Modelo Estudiante, y las diferencias entre fusión temprana, intermedia y tardía. Se explican las siglas y términos usados.

El objetivo general y los siete específicos se conservan íntegros desde [[Estructura Tesis]]. Se mantiene KDD, la partición por participante y la separación de señales. Las curvas de portada son esquemáticas, con ese carácter declarado en la lámina. No se generaron nuevos resultados de modelos.

Se reemplazaron en las rutas originales:

- `Tesis_MDS/presentaciones/Presentacion-Tema-Tesis-Autocontenida-20-09-2026.html`.
- `Tesis_MDS/presentaciones/Presentacion-Tema-Tesis-Autocontenida-20-09-2026.pptx`.

Se añadió el PDF homónimo. El HTML funciona offline con los gráficos incluidos; el PowerPoint tiene objetos editables. En móvil, los diagramas tienen una explicación textual para mantener la lectura.

Verificación: 34 comprobaciones de HTML, siete páginas de impresión y revisión de accesibilidad automatizada sin violaciones detectadas en tres anchos. Apertura y renderizado de siete láminas en PowerPoint, sin texto desbordado dentro de la tolerancia de dos puntos. PDF final de siete páginas; contenido y hashes verificados. Se revisó la composición de las láminas y la lectura móvil de KDD, etiquetas y fusión. No se probó la importación dentro de Canva ni un lector de pantalla real.

Detalle: `Tesis_MDS/documentacion/Presentacion_Visual_KDD_23-09-2026.md`. Respaldo: `Tesis_MDS/documentacion/Tesis_Vault_Presentacion_Visual_24-09-2026.zip`.

**Cierre del 24-09-2026:** se retomó la entrega y se comprobó que el HTML, el PPTX y el PDF correspondieran a los archivos verificados. Presentación, generador e informes guardados en el commit `c1a75f2`. El respaldo conserva esta nota y el índice actualizado.

Fuentes: [[Estructura Tesis]], [[Tesis_MDS]], [[PREPROCESAMIENTO_MULTIMODAL]], partición y características guardadas. KDD adaptado de Fayyad, Piatetsky-Shapiro y Smyth (1996), [fuente primaria consultada el 22-09](https://fayyad.com/from-data-mining-to-knowledge-discovery-in-databases/), DOI 10.1609/aimag.v17i3.1230.

Reemplaza como presentación vigente a la revisión documentada en [[Avance - 22-09-2026 (Objetivos Cientificos y Metodologia KDD)]].
